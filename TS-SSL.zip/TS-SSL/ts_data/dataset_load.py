import torch
import torch.utils.data as data

from .augmentations import DataTransform

class UCR_Dataset(data.Dataset):
    def __init__(self, dataset, target, config=None):
        self.dataset = dataset
        if len(self.dataset.shape) == 2:
            self.dataset = torch.unsqueeze(self.dataset, 1)
        self.target = target
        self.aug1, self.aug2= DataTransform(self.dataset, config)

    def __getitem__(self, index):
        return self.dataset[index], self.aug1[index], self.aug2[index], self.target[index]

    def __len__(self):
        return len(self.target)


class ECG_Dataset(data.Dataset):
    def __init__(self, dataset, target, config=None):
        self.dataset = dataset
        if len(self.dataset.shape) == 2:
            self.dataset = torch.unsqueeze(self.dataset, 1)
        self.target = target

    def __getitem__(self, index):
      
        return self.dataset[index], self.target[index]
    
    def __len__(self):
        return len(self.target)
    
class Load_Dataset(data.Dataset):
    def __init__(self, dataset, target, config=None):
        self.dataset = dataset
        if len(self.dataset.shape) == 2:
            self.dataset = torch.unsqueeze(self.dataset, 1)
        self.target = target

    def __getitem__(self, index):
      
        return self.dataset[index], self.target[index]
    
    def __len__(self):
        return len(self.target)

# Augmented 
class Load_Aug_Dataset(data.Dataset):
    def __init__(self, dataset, target, config=None):
        self.dataset = dataset
        if len(self.dataset.shape) == 2:
            self.dataset = torch.unsqueeze(self.dataset, 1)
        self.target = target
        self.aug1, self.aug2= DataTransform(self.dataset, config)

    def __getitem__(self, index):
      
        return self.dataset[index], self.aug1[index], self.aug2[index], self.target[index]
    

    def __len__(self):
        return len(self.target)


if __name__ == '__main__':
    pass

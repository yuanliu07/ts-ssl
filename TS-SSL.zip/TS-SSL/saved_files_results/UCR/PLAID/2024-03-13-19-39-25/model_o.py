import torch
import torch.nn as nn
import torch.nn.functional as F

class SqueezeChannels(nn.Module):
    def __init__(self):
        super(SqueezeChannels, self).__init__()

    def forward(self, x):
        return x.squeeze(2)


class FCN(nn.Module):
    def __init__(self, num_classes, input_size=1):
        super(FCN, self).__init__()

        self.num_classes = num_classes
        self.conv_block1 = nn.Sequential(
            nn.Conv1d(in_channels=input_size, out_channels=128, kernel_size=8, padding='same'),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv1d(in_channels=128, out_channels=256, kernel_size=5, padding='same'),
            nn.BatchNorm1d(256),
            nn.ReLU()
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv1d(in_channels=256, out_channels=128, kernel_size=3, padding='same'),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.network = nn.Sequential(
            self.conv_block1,
            self.conv_block2,
            self.conv_block3,
            nn.AdaptiveAvgPool1d(1),
            SqueezeChannels(),
        )

    def forward(self, x, vis=False):
        if vis: # 没用
            with torch.no_grad():
                vis_out = self.conv_block1(x)
                vis_out = self.conv_block2(vis_out)
                vis_out = self.conv_block3(vis_out)
                return self.network(x), vis_out

        return self.network(x)


class Classifier(nn.Module):
    def __init__(self, input_dims, output_dims) -> None:
        super(Classifier, self).__init__()

        self.dense = nn.Linear(input_dims, output_dims)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        return self.softmax(self.dense(x))


class ProjectionHead(nn.Module):
    def __init__(self, input_dim, embedding_dim=64, output_dim=32) -> None:
        super(ProjectionHead, self).__init__()
        self.projection_head = nn.Sequential(
            nn.Linear(input_dim, embedding_dim),
            nn.BatchNorm1d(embedding_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embedding_dim, output_dim),
        )

    def forward(self, x):
        return self.projection_head(x)


class BiLSTM(nn.Module):
    def __init__(self, num_classes, input_size=1, hidden_size=128, out_size=64, num_layers=1):
        super(BiLSTM, self).__init__()

        self.num_classes = num_classes
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.out_size  = out_size

        # BiLSTM Layer
        self.lstm = nn.LSTM(input_size=input_size, hidden_size=hidden_size, 
                            num_layers=num_layers, batch_first=True, bidirectional=True)
        
        # Fully connected layer
        self.fc = nn.Linear(hidden_size*2, self.hidden_size)  # Multiply by 2 for bidirectional

    def forward(self, x):
        # LSTM layer
        x_in = x.permute(0, 2, 1)
        h, _ = self.lstm(x_in) # torch.Size([128, 1, 1500])
        
        # Select the last time step's output
        h = h[:, -1, :]
        
        # Fully connected layer
        out = self.fc(h)
        return out


class DilatedCNN(nn.Module):
    def __init__(self, num_classes, input_size=1):
        super(DilatedCNN, self).__init__()

        self.num_classes = num_classes
        self.conv_block1 = nn.Sequential(   # 替换conv1d为膨胀卷积层
            nn.Conv1d(in_channels=input_size, out_channels=128, kernel_size=8, padding='same', dilation=1),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv1d(in_channels=128, out_channels=256, kernel_size=5, padding='same', dilation=2),
            nn.BatchNorm1d(256),
            nn.ReLU()
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv1d(in_channels=256, out_channels=128, kernel_size=3, padding='same', dilation=4),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.network = nn.Sequential(
            self.conv_block1,
            self.conv_block2,
            self.conv_block3,
            nn.AdaptiveAvgPool1d(1),
            SqueezeChannels(),
        )

    def forward(self, x, vis=False):
        if vis:
            with torch.no_grad():
                vis_out = self.conv_block1(x)
                vis_out = self.conv_block2(vis_out)
                vis_out = self.conv_block3(vis_out)
                return self.network(x), vis_out

        return self.network(x)

class FCN_prj(nn.Module):
    def __init__(self, num_classes, input_size=1):
        super(FCN_prj, self).__init__()

        self.num_classes = num_classes
        self.conv_block1 = nn.Sequential(
            nn.Conv1d(in_channels=input_size, out_channels=128, kernel_size=8, padding='same'),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv1d(in_channels=128, out_channels=256, kernel_size=5, padding='same'),
            nn.BatchNorm1d(256),
            nn.ReLU()
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv1d(in_channels=256, out_channels=128, kernel_size=3, padding='same'),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.network = nn.Sequential(
            self.conv_block1,
            self.conv_block2,
            self.conv_block3,
            nn.AdaptiveAvgPool1d(1),
            SqueezeChannels(),
        )

        self.projector=nn.Sequential(nn.Linear(128, 256, bias=False),  
                                nn.Dropout(p=0.5),
                                nn.BatchNorm1d(256),
                                nn.ReLU(inplace=True), # first layer
                                # nn.Linear(128, 128, bias=False),
                                # nn.Dropout(p=0.5),
                                # nn.BatchNorm1d(128),
                                # nn.ReLU(inplace=True), # second layer
                                nn.Linear(256, 128),
                                nn.Dropout(p=0.5),
                                nn.BatchNorm1d(128, affine=False)) # output layer
        self.projector[4].bias.requires_grad = False # hack: not use bias as it is followed by BN

        self.predictor=nn.Sequential(nn.Linear(128, 256, bias=False),
                                nn.Dropout(p=0.5),
                                nn.BatchNorm1d(256),
                                nn.ReLU(inplace=True), # hidden layer
                                nn.Linear(256, 128)) # output layer


    def forward(self, x):
        out = self.network(x)
        out_proj = self.projector(F.normalize(out, dim=1))
        out_pred = self.predictor(out_proj)
        return out, out_proj, out_pred

class FCN_expert(nn.Module):
    def __init__(self, num_classes, input_size=1):
        super(FCN_expert, self).__init__()

        self.num_classes = num_classes
        self.conv_block1 = nn.Sequential(
            nn.Conv1d(in_channels=input_size, out_channels=128, kernel_size=8, padding='same'),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv1d(in_channels=128, out_channels=256, kernel_size=5, padding='same'),
            nn.BatchNorm1d(256),
            nn.ReLU()
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv1d(in_channels=256, out_channels=128, kernel_size=3, padding='same'),
            nn.BatchNorm1d(128),
            nn.ReLU()
        )

        self.network = nn.Sequential(
            self.conv_block1,
            self.conv_block2,
            self.conv_block3,
            nn.AdaptiveAvgPool1d(1),
            SqueezeChannels(),
        )

    def forward(self, x, vis=False):
        if vis: # 没用
            with torch.no_grad():
                vis_out = self.conv_block1(x)
                vis_out = self.conv_block2(vis_out)
                vis_out = self.conv_block3(vis_out)
                return self.network(x), vis_out

        return self.network(x)
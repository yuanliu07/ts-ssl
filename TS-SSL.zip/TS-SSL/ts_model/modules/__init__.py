from .classifier_ops import *
from .pooling_ops import GAP, Identity


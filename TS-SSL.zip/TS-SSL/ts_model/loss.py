import torch
import torch.nn as nn
import torch.nn.functional as F



EPS = 1e-8


def cross_entropy():
    loss = nn.CrossEntropyLoss()
    return loss

def reconstruction_loss():
    loss = nn.MSELoss()
    return loss

def focal_loss(inputs, targets, num_class, alpha=0.25,  gamma=2.0):
    # 转换为 one-hot 编码
    targets_one_hot = F.one_hot(targets, num_classes=num_class).float()
    # 计算焦点损失
    inputs_softmax = F.softmax(inputs, dim=1)
    inputs_log_softmax = torch.log(inputs_softmax)
    focal_loss = -alpha * (1 - inputs_softmax) ** gamma * targets_one_hot * inputs_log_softmax

    # 适用于多分类，因此取平均
    return focal_loss.mean()

def symmetric_cross_entropy(inputs, targets,num_classes, alpha=0.1, beta=1.0):
    # 传统交叉熵损失
    ce_loss = F.cross_entropy(inputs, targets)
    # 反交叉熵损失
    targets_one_hot = F.one_hot(targets, num_classes=num_classes).float()
    rce_loss = -torch.mean(torch.sum(F.log_softmax(inputs, dim=1) * targets_one_hot, dim=1))

    # 组合交叉熵和反交叉熵
    return alpha * ce_loss + beta * rce_loss

class combined_loss(nn.Module):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        # self.args = args
        # self.kwargs = kwargs

    def forward(self, inputs, targets, num_class, lambda_weight=0.5, alpha=0.25, gamma=2.0, **kwargs):
        classifier_num = len(inputs)
        fl = 0
        sce = 0
        if "single_input_flag" in kwargs:
            fl = focal_loss(inputs, targets, num_class, alpha, gamma)
            sce = symmetric_cross_entropy(inputs, targets, num_class)
            return lambda_weight * fl + (1 - lambda_weight) * sce
        
        for i in range(classifier_num):
            fl += focal_loss(inputs[i], targets, num_class, alpha, gamma)
            sce += symmetric_cross_entropy(inputs[i], targets, num_class)
        return lambda_weight * fl + (1 - lambda_weight) * sce
        

def sup_contrastive_loss(embd_batch_1, labels, device, num_experts,
                         temperature=0.07, base_temperature=0.07):
    # InfoNCEIn
    loss = 0
    cur_loss = 0
    if len(embd_batch_1) == 2:
        embd_batch_1, embd_batch_2 = embd_batch_1
    else:
        embd_batch_2 = embd_batch_1

    # 单输入：
    # 计算相似度矩阵
    anchor_dot_contrast = torch.div(    # torch.Size([32, 32])
        torch.matmul(embd_batch_1, embd_batch_2.T),   # 2.23 embd_batch_1
        temperature)
     
    # 数值稳定性调整：从 anchor_dot_contrast 中每行中找到最大值（为了数值稳定性），并从 anchor_dot_contrast 的每个元素中减去这个最大值
    try:
        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()
    except:
        print('anchor_dot_contrast 为标量')
        print(embd_batch_1.shape)
        print(embd_batch_2.shape)
        
    # 创建掩码矩阵：将标签转换为列向量，并创建一个掩码矩阵，其中相同标签的位置为 1，不同标签的位置为 0
    labels = labels.contiguous().view(-1, 1)
    mask = torch.eq(labels, labels.T).float().to(device)

    # 排除自身的对比：创建一个掩码来排除自身比较（对角线上的元素）
    logits_mask = torch.scatter(
        torch.ones_like(logits.detach()),
        1,
        torch.arange(embd_batch_1.shape[0]).view(-1, 1).to(device),    # 2.25 embd_batch_1[i]
        0
    )
    mask = mask * logits_mask

    # compute log_prob 计算对数概率：对 logits 应用指数函数并应用掩码，然后计算对数概率。
    exp_logits = torch.exp(logits) * logits_mask
    log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True) + 1e-12)

    # 计算正样本的对数概率均值：对于每个锚点，计算与正样本对应的对数概率的均值
    mean_log_prob_pos = (mask * log_prob).sum(1) / (mask.sum(1) + 1e-12)

    # 计算有效锚点数：计算有至少一个正样本的锚点数量
    num_anchor = (mask.sum(1) != 0).sum().item()
            
    # 计算最终损失：根据正样本对数概率均值和有效锚点数计算最终的损失。
    cur_loss = - (temperature / base_temperature) * mean_log_prob_pos
    loss = cur_loss.sum(0) /  (num_anchor + 1e-12)   # 避免除以0

    return loss

def MoCo_loss(c1, c2, model):
    loss_CON = 0
    # 多专家：
    for i, (q, k) in enumerate(zip(c1, c2)):
        q = F.normalize(q, dim=1)
        k = F.normalize(k, dim=1)
        # compute logits
        # Einstein sum is more intuitive
        # positive logits: Nx1
        l_pos = torch.einsum('nc,nc->n', [q, k]).unsqueeze(-1)

        # negative logits: NxK
        # 负样本对相似度 negative logits: NxK torch.Size([64, 1024])
        l_neg = torch.einsum('nc,ck->nk', [q, model.MOCO[i].queue.clone().detach()])

        # logits: Nx(1+K)
        logits = torch.cat([l_pos, l_neg], dim=1)

        # apply temperature
        logits /= model.MOCO[i].T

        # labels: positive key indicators
        labels = torch.zeros(logits.shape[0], dtype=torch.long).cuda()

        model.MOCO[i]._dequeue_and_enqueue(k)

        loss_CON += F.cross_entropy(logits, labels)
        
        # loss = loss_ce + loss_CON * self.CON_ratio
    return loss_CON
    

def NBOD(inputs, factor):

    classifier_num = len(inputs)
    if classifier_num == 1:
        return 0
    logits_softmax = []
    logits_logsoftmax = []
    for i in range(classifier_num):
        logits_softmax.append(F.softmax(inputs[i], dim=1) + 1e-12)
        logits_logsoftmax.append(torch.log(logits_softmax[i] + 1e-12))

    loss_mutual = 0
    for i in range(classifier_num):
        for j in range(classifier_num):
            if i == j:
                continue
            loss_mutual += factor * F.kl_div(logits_logsoftmax[i], logits_softmax[j], reduction='batchmean')
    loss_mutual /= (classifier_num - 1)
    return  loss_mutual

def KL(inputs, factor):

    classifier_num = len(inputs)
    if classifier_num == 1:
        return 0
    logits_softmax = []
    logits_logsoftmax = []
    for i in range(classifier_num):
        logits_softmax.append(F.softmax(inputs[i], dim=1) + 1e-12)
        logits_logsoftmax.append(torch.log(logits_softmax[i] + 1e-12))

    loss_mutual = 0
    for i in range(classifier_num):
        for j in range(classifier_num):
            if i == j:
                continue
            loss_mutual += factor * F.kl_div(logits_logsoftmax[i], logits_softmax[j], reduction='batchmean')

    return  loss_mutual

class NIL_NBOD(nn.Module):
    def __init__(self, config, num_class_list):
        super(NIL_NBOD, self).__init__()
        self.num_class_list = num_class_list
        self.device = 'cuda' if torch.cuda.is_available else 'cpu'
        self.bsce_weight = torch.FloatTensor(self.num_class_list).to(self.device)

        self.multi_classifier_diversity_factor = config.loss.diversity_factor
        self.multi_classifier_diversity_factor_hcm = config.loss.diversity_factor_hcm
        self.hcm_N = config.loss.hcm_n
        self.hcm_ratio = config.loss.hcm_ratio
        self.ce_ratio = config.loss.ce_ratio

        self.combined_loss = combined_loss()

    def forward(self, inputs, targets, num_class, **kwargs):
        """
        Args:
            inputs: prediction matrix (before softmax) with shape (classifier_num, batch_size, num_classes)
            targets: ground truth labels with shape (classifier_num, batch_size)
        """
        classifier_num = len(inputs)
        loss_HCM = 0
        loss = 0
        los_ce = 0

        inputs_HCM_balance = []
        inputs_balance = []

        batch_size = targets.shape

        class_select = inputs[0].scatter(1, targets.unsqueeze(1), 999999)
        class_select_include_target = class_select.sort(descending=True, dim=1)[1][:, :self.hcm_N]
        # class_select_include_target = class_select.sort(descending=True, dim=1)[1][:, :batch_size // 4]
        mask = torch.zeros_like(inputs[0]).scatter(1, class_select_include_target, 1)
        
        for i in range(classifier_num):

            logits = inputs[i] + self.bsce_weight.unsqueeze(0).expand(inputs[i].shape[0], -1).log()
            inputs_balance.append(logits)
            inputs_HCM_balance.append(logits * mask)

            los_ce += F.cross_entropy(logits, targets)
            loss_HCM += F.cross_entropy(inputs_HCM_balance[i], targets)

        loss += KL(inputs_balance, factor=self.multi_classifier_diversity_factor)
        loss += KL(inputs_HCM_balance, factor=self.multi_classifier_diversity_factor_hcm)
        loss += los_ce * self.ce_ratio + loss_HCM * self.hcm_ratio

        return loss

    def update(self, epoch):
        """
        Args:
           code can be added for progressive loss.
        """
        pass
import torch
import torch.nn as nn

EPS = 1e-8


def cross_entropy():
    loss = nn.CrossEntropyLoss()
    return loss


def reconstruction_loss():
    loss = nn.MSELoss()
    return loss


def sup_contrastive_loss(embd_batch, labels, device,
                         temperature=0.07, base_temperature=0.07):
    # 计算相似度矩阵
    anchor_dot_contrast = torch.div(
        torch.matmul(embd_batch, embd_batch.T),
        temperature)
    
    # 数值稳定性调整：从 anchor_dot_contrast 中每行中找到最大值（为了数值稳定性），并从 anchor_dot_contrast 的每个元素中减去这个最大值
    logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
    logits = anchor_dot_contrast - logits_max.detach()  

    # 创建掩码矩阵：将标签转换为列向量，并创建一个掩码矩阵，其中相同标签的位置为 1，不同标签的位置为 0
    labels = labels.contiguous().view(-1, 1)
    mask = torch.eq(labels, labels.T).float().to(device)

    # 排除自身的对比：创建一个掩码来排除自身比较（对角线上的元素）
    logits_mask = torch.scatter(
        torch.ones_like(logits.detach()),
        1,
        torch.arange(embd_batch.shape[0]).view(-1, 1).to(device),
        0
    )
    mask = mask * logits_mask
    # compute log_prob 计算对数概率：对 logits 应用指数函数并应用掩码，然后计算对数概率。
    exp_logits = torch.exp(logits) * logits_mask
    log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True) + 1e-12)

    # 计算正样本的对数概率均值：对于每个锚点，计算与正样本对应的对数概率的均值
    mean_log_prob_pos = (mask * log_prob).sum(1) / (mask.sum(1) + 1e-12)

    # 计算有效锚点数：计算有至少一个正样本的锚点数量
    num_anchor = 0
    for s in mask.sum(1):
        if s != 0:
            num_anchor = num_anchor + 1
            
    # 计算最终损失：根据正样本对数概率均值和有效锚点数计算最终的损失。
    loss = - (temperature / base_temperature) * mean_log_prob_pos
    loss = loss.sum(0) / (num_anchor + 1e-12)

    return loss

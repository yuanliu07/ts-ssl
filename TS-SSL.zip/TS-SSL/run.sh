# source activate D:/wyd/tsc/envs

# sleep 15s

# python multi_experts_main_ts_tfc.py

# sleep 300s

# python multi_experts_main_ts_tfc_aug.py

# sleep 300s

# python multi_experts_main_ts_tfc_aug.py --dataset ECG --configs ECG --warmup_epochs 30 --epoch 100 --batch_size 128 --log_epoch 1

# python multi_experts_main_ts_tfc_aug.py --backbone tc --dataset ECG --configs ECG

# sleep 300s

# python multi_experts_main_ts_tfc_aug.py --backbone fcn --dataset ECG --configs ECG

# python main_ts_tfc_o.py --dataset InsectEPGRegularTrain --configs UCR

python main_ts_tfc_o.py
sleep 300s
# python main_ts_tfc_3_9.py
# sleep 300s
# python main_ts_tfc_o.py --backbone dilated --dataset ECG 
class Config(object):
    def __init__(self):
        self.wandb = False

        self.noisy_ratio = 0
        self.labeled_ratio = 0.01
       
        # model configs
        self.input_channels = 1
        self.kernel_size = 8
        self.stride = 1
        self.final_out_channels = 128

        # self.num_classes = 2
        self.dropout = 0.35
        self.features_len = 24

        # training configs
        self.num_epoch = 100
        self.num_workers = 0
        self.lr_scheduler = 'warmup'
        self.use_dropout=True

        # optimizer parameters
        self.beta1 = 0.9
        self.beta2 = 0.99
        self.lr = 3e-4

        # data parameters
        self.drop_last = False
        self.batch_size = 128

        self.Context_Cont = Context_Cont_configs()
        self.TC = TC()
        self.augmentation = augmentation()

        # loss
        self.loss = Loss()
        # KL 
        self.factor_1 = 0.5
        self.factor_2 = 0.5
        self.factor_3 = 0.5
        # Moco
        self.MOCO_K = 1024
        self.MOCO_T = 0.2
        self.MOCO_DIM = 64

        # factor of CL loss for unlabeled data
        self.lambda1 = 1
        self.lambda2 = 0.7

        # factor of CL loss for labeled data
        self.gamma1 = 1
        self.gamma2 = 1

        self.wb_visual = False
        
class augmentation(object):
    def __init__(self):
        self.jitter_scale_ratio = 0.001
        self.jitter_ratio = 0.001
        self.max_seg = 5


class Context_Cont_configs(object):
    def __init__(self):
        self.temperature = 0.2
        self.use_cosine_similarity = True

class Loss(object):
    def __init__(self):
        self.loss_type = 'NIL_NBOD' # cross_entropy; combined; NIL_NBOD
        self.diversity_factor = 0.6
        self.diversity_factor_hcm = 0.6
        
        self.hcm_n = 30
        self.hcm_ratio = 1.0
        self.ce_ratio = 1.0
        self.contrastive_ratio = 0.5
        
class TC(object):
    def __init__(self):
        self.hidden_dim = 64
        self.timesteps = 10



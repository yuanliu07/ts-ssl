import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class LogitAdjust(nn.Module):

    def __init__(self, cls_num_list, tau=1, weight=None):
        super(LogitAdjust, self).__init__()
        cls_num_list = torch.cuda.FloatTensor(cls_num_list)
        cls_p_list = cls_num_list / cls_num_list.sum()
        m_list = tau * torch.log(cls_p_list)
        self.m_list = m_list.view(1, -1)
        self.weight = weight

    def forward(self, x, target):
        loss = 0
        for i in range(len(x)):
            x_m = x[i] + self.m_list
            loss += F.cross_entropy(x_m, target, weight=self.weight)
        return loss
        
        # x_m = x + self.m_list
        # return F.cross_entropy(x_m, target, weight=self.weight)

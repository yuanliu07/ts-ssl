"""
Author: Yonglong Tian (yonglong@mit.edu)
Date: May 07, 2020
"""
from __future__ import print_function

import torch
import torch.nn as nn


class BalSCL(nn.Module):
    def __init__(self, cls_num_list=None, temperature=0.07, num_experts=3):
        super(BalSCL, self).__init__()
        self.temperature = temperature
        self.cls_num_list = cls_num_list
        self.num_experts = num_experts

    def forward(self, centers1, features, targets, ):   # centers的shapey应该是 [batch_size, num_classes]

        device = (torch.device('cuda')
                  if features[0].is_cuda
                  else torch.device('cpu'))

        batch_size = features[0].shape[0]
        targets = targets.contiguous().view(-1, 1)  # targets: [128, 1]
        targets_centers = torch.arange(len(self.cls_num_list), device=device).view(-1, 1)   # [11, 1]
        targets = torch.cat([targets, targets_centers], dim=0)
        # targets = torch.cat([targets.repeat(2, 1), targets_centers], dim=0)
        batch_cls_count = torch.eye(len(self.cls_num_list), device=device)[targets].sum(dim=0).squeeze()
        

        mask = torch.eq(targets[:2 * batch_size], targets.T).float().to(device)
        logits_mask = torch.scatter(
            torch.ones_like(mask),
            1,
            torch.arange(batch_size * 2).view(-1, 1).to(device),
            0
        )
        mask = mask * logits_mask
        loss=0
        for i in range(self.num_experts):
            # class-complement
            feat = torch.cat(torch.unbind(features[i], dim=1), dim=0)
            feat = torch.cat([feat, centers1[i]], dim=0)
            logits = feat[:2 * batch_size].mm(feat.T)
            logits = torch.div(logits, self.temperature)

            # For numerical stability
            logits_max, _ = torch.max(logits, dim=1, keepdim=True)
            logits = logits - logits_max.detach()

            # class-averaging
            exp_logits = torch.exp(logits) * logits_mask
            per_ins_weight = torch.tensor([batch_cls_count[i] for i in targets], device=device).view(1, -1).expand(
                2 * batch_size, 2 * batch_size + len(self.cls_num_list)) - mask
            exp_logits_sum = exp_logits.div(per_ins_weight).sum(dim=1, keepdim=True)
            
            log_prob = logits - torch.log(exp_logits_sum)
            mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)

            cur_loss = - mean_log_prob_pos
            loss = loss + cur_loss.view(2, batch_size).mean()
        return loss

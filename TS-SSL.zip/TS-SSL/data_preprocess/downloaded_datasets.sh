wget -O SleepEEG.zip https://figshare.com/ndownloader/articles/19930178/versions/1
wget -O Epilepsy.zip https://figshare.com/ndownloader/articles/19930199/versions/2
wget -O FD-A.zip https://figshare.com/ndownloader/articles/19930205/versions/1
wget -O FD-B.zip https://figshare.com/ndownloader/articles/19930226/versions/1
wget -O HAR.zip https://figshare.com/ndownloader/articles/19930244/versions/1
wget -O Gesture.zip https://figshare.com/ndownloader/articles/19930247/versions/1
wget -O ECG.zip https://figshare.com/ndownloader/articles/19930253/versions/1
wget -O EMG.zip https://figshare.com/ndownloader/articles/19930250/versions/1

unzip SleepEEG.zip -d datasets/SleepEEG/
unzip  Epilepsy.zip -d datasets/Epilepsy/
unzip  FD-A.zip -d datasets/FD-A/
unzip  FD-B.zip -d datasets/FD-B/
unzip  HAR.zip -d datasets/HAR/
unzip  Gesture.zip -d datasets/Gesture/
unzip  ECG.zip -d datasets/ECG/
unzip  EMG.zip -d datasets/EMG/

rm {SleepEEG,Epilepsy,FD-A,FD-B,HAR,Gesture,ECG,EMG}.zip
# 创建软链接
mkdir code/baselines/TS-TCC/data/{SleepEEG,Epilepsy,FD-A,FD-B,HAR,Gesture,ECG,EMG}
ln -s E:/ts_data/SleepEEG/{train,val,test}.pt code/baselines/TS-TCC/data/SleepEEG/
ln -s E:/ts_data/Epilepsy/{train,val,test}.pt code/baselines/TS-TCC/data/Epilepsy/
ln -s E:/ts_data/FD-A/{train,val,test}.pt code/baselines/TS-TCC/data/FD-A/
ln -s E:/ts_data/FD-B/{train,val,test}.pt code/baselines/TS-TCC/data/FD-B/
ln -s E:/ts_data/HAR/{train,val,test}.pt code/baselines/TS-TCC/data/HAR/
ln -s E:/ts_data/Gesture/{train,val,test}.pt code/baselines/TS-TCC/data/Gesture/
ln -s E:/ts_data/ECG/{train,val,test}.pt code/baselines/TS-TCC/data/ECG/
ln -s E:/ts_data/EMG/{train,val,test}.pt code/baselines/TS-TCC/data/EMG/




import os
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold
import torch
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from sklearn import datasets
from sklearn.svm import SVC
from collections import Counter
import json
from scipy.io.arff import loadarff
from sklearn.preprocessing import StandardScaler, MinMaxScaler

def load_UEA(configs, dataset_path, dataset, noisy_ratio, labeled_ratio, logger):

    train_data = loadarff(f'D:/wyd/tsc/raw_data/UEA_arff/{dataset}/{dataset}_TRAIN.arff')[0]
    test_data = loadarff(f'D:/wyd/tsc/raw_data/UEA_arff/{dataset}/{dataset}_TEST.arff')[0]
    
    output_dir = os.path.join(dataset_path, dataset)

    def extract_data(data):
        res_data = []
        res_labels = []
        for t_data, t_label in data:
            t_data = np.array([ d.tolist() for d in t_data ])
            t_label = t_label.decode("utf-8")
            res_data.append(t_data)
            res_labels.append(t_label)
        return np.array(res_data).swapaxes(1, 2), np.array(res_labels)
    
    X_train, y_train = extract_data(train_data)
    X_test, y_test = extract_data(test_data)
    
    scaler = StandardScaler()
    scaler.fit(X_train.reshape(-1, X_train.shape[-1]))
    X_train = scaler.transform(X_train.reshape(-1, X_train.shape[-1])).reshape(X_train.shape)
    X_test = scaler.transform(X_test.reshape(-1, X_test.shape[-1])).reshape(X_test.shape)
    
    labels = np.unique(y_train)
    transform = { k : i for i, k in enumerate(labels)}
    y_train = np.vectorize(transform.get)(y_train)
    y_test = np.vectorize(transform.get)(y_test)

    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

    # pseudo
    nosiy_labeled_dict = dict()
    unlabeled_dict = dict()
    # p_data['samples'] = torch.from_numpy(X_train).unsqueeze(1)

    p_X_train, p_y_train, unlabeled_X_train = gen_noisy_unlabeled_data(X_train=X_train, y_train=y_train, noisy_ratio=noisy_ratio, labeled_ratio=labeled_ratio, logger=logger)
    
    nosiy_labeled_dict['samples'] = torch.from_numpy(p_X_train).unsqueeze(1)
    unlabeled_dict['samples'] = torch.from_numpy(unlabeled_X_train).unsqueeze(1)
    nosiy_labeled_dict["labels"] = torch.from_numpy(p_y_train)

    torch.save(nosiy_labeled_dict, os.path.join(output_dir, "train_labeled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))    
    torch.save(unlabeled_dict, os.path.join(output_dir, "train_unlabled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))
    
    val_dict = dict()
    val_dict["samples"] = torch.from_numpy(X_val).unsqueeze(1)
    val_dict["labels"] = torch.from_numpy(y_val)
    torch.save(val_dict, os.path.join(output_dir, "val.pt"))
   
    test_dict = dict()
    test_dict["samples"] = torch.from_numpy(X_test).unsqueeze(1)
    test_dict["labels"] = torch.from_numpy(y_test)
    torch.save(test_dict, os.path.join(output_dir, "test.pt"))
    
    train_counts = Counter(y_train)
    print("训练集中每个类别的样本数量:", train_counts)
    
    val_counts = Counter(y_val)
    print("测试集中每个类别的样本数量:", val_counts)
    
    test_counts = Counter(y_test)
    print("测试集中每个类别的样本数量:", test_counts)

    # return X_train, y_train, X_test, y_test
    return nosiy_labeled_dict, unlabeled_dict, val_dict, test_dict


def load_Epilepsy(configs, data_set_path, dataset, noisy_ratio, labeled_ratio, logger):
    
    data = pd.read_csv(os.path.join(data_set_path, "Epilepsy", "data_files", "data.csv"))
    output_dir = os.path.join(data_set_path, "dataset", "Epilepsy")

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    y = data.iloc[:, -1]
    x = data.iloc[:, 1:-1]

    x = x.to_numpy()
    y = y.to_numpy()
    y = y - 1
    scaler = MinMaxScaler()
    x = scaler.fit_transform(x)

    for i, j in enumerate(y):
        if j != 0:
            y[i] = 1

    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

    train_dict = dict()
    train_dict["samples"] = torch.from_numpy(X_train)
    train_dict["labels"] = torch.from_numpy(y_train)
    torch.save(train_dict, os.path.join(output_dir, "train.pt"))
    
    # pseudo
    nosiy_labeled_dict= dict()
    unlabeled_dict = dict()

    noisy_X_train, noisy_y_train, unlabeled_X_train = gen_noisy_unlabeled_data(X_train=X_train, y_train=y_train, noisy_ratio=noisy_ratio, labeled_ratio=labeled_ratio, logger=logger)
    
    nosiy_labeled_dict['samples'] = torch.from_numpy(noisy_X_train).unsqueeze(1)
    unlabeled_dict['samples'] = torch.from_numpy(unlabeled_X_train).unsqueeze(1)
    nosiy_labeled_dict["labels"] = torch.from_numpy(noisy_y_train)
    
    torch.save(nosiy_labeled_dict, os.path.join(output_dir, "train_labeled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))    
    torch.save(unlabeled_dict, os.path.join(output_dir, "train_unlabled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))
    
    val_dict = dict()
    val_dict["samples"] = torch.from_numpy(X_val).unsqueeze(1)
    val_dict["labels"] = torch.from_numpy(y_val)
    torch.save(val_dict, os.path.join(output_dir, "val.pt"))
   
    test_dict = dict()
    test_dict["samples"] = torch.from_numpy(X_test).unsqueeze(1)
    test_dict["labels"] = torch.from_numpy(y_test)
    torch.save(test_dict, os.path.join(output_dir, "test.pt"))
    
    train_counts = Counter(y_train)
    print("训练集中每个类别的样本数量:", train_counts)
    
    val_counts = Counter(y_val)
    print("测试集中每个类别的样本数量:", val_counts)
    
    test_counts = Counter(y_test)
    print("测试集中每个类别的样本数量:", test_counts)

    return nosiy_labeled_dict, unlabeled_dict, val_dict, test_dict

def load_UCR(configs, dataset_path, dataset, noisy_ratio, labeled_ratio, logger):
    # E:\ts_data\UCRArchive_2018\AllGestureWiimoteX
    train = pd.read_csv(os.path.join(dataset_path, "UCR", dataset, dataset + '_TRAIN.tsv'), sep='\t', header=None)
    train_x = train.iloc[:, 1:]
    train_target = train.iloc[:, 0]

    test = pd.read_csv(os.path.join(dataset_path, "UCR", dataset, dataset + '_TEST.tsv'), sep='\t', header=None)
    test_x = test.iloc[:, 1:]
    test_target = test.iloc[:, 0]

    # # Move the labels to {0, ..., L-1}
    

    sum_dataset = pd.concat([train_x, test_x]).to_numpy(dtype=np.float32) 
    sum_target = pd.concat([train_target, test_target]).to_numpy(dtype=np.float32)

    num_classes = len(np.unique(sum_target))
    configs.num_classes = num_classes

    output_dir = os.path.join(dataset_path, dataset)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(np.column_stack((train_target, train_x)))
    X_test = scaler.fit_transform(np.column_stack((test_target, test_x)))

    X_train, X_val, y_train, y_val = train_test_split(X_train, train_target, test_size=0.2, random_state=42)

    train_set, val_set, test_set = fill_nan_value(X_train, X_val, X_test)
    y_train = transfer_labels(y_train)
    y_val = transfer_labels(y_val)
    y_test = transfer_labels(test_target)    

    train_dict = dict()
    train_dict["samples"] = torch.from_numpy(X_train).unsqueeze(1)
    train_dict["labels"] = torch.from_numpy(y_train)
    torch.save(train_dict, os.path.join(output_dir, "train.pt"))
    
    # pseudo
    nosiy_labeled_dict = dict()
    unlabeled_dict = dict()
   
    p_X_train, p_y_train, unlabeled_X_train = gen_noisy_unlabeled_data(X_train=train_set, y_train=y_train, noisy_ratio=noisy_ratio, labeled_ratio=labeled_ratio, logger=logger)
    nosiy_labeled_dict['samples'] = torch.from_numpy(p_X_train).unsqueeze(1)
    unlabeled_dict['samples'] = torch.from_numpy(unlabeled_X_train).unsqueeze(1)
    nosiy_labeled_dict["labels"] = torch.from_numpy(p_y_train)
    torch.save(nosiy_labeled_dict, os.path.join(output_dir, "train_labeled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))    
    torch.save(unlabeled_dict, os.path.join(output_dir, "train_unlabled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))
    
    val_dict = dict()
    val_dict["samples"] = torch.from_numpy(val_set).unsqueeze(1)
    val_dict["labels"] = torch.from_numpy(y_val)
    torch.save(val_dict, os.path.join(output_dir, "val.pt"))

    test_dict = dict()
    test_dict["samples"] = torch.from_numpy(test_set).unsqueeze(1)
    test_dict["labels"] = torch.from_numpy(y_test)
    torch.save(test_dict, os.path.join(output_dir, "test.pt"))
    
    # 计算训练集中每个类别的样本数量
    train_counts = Counter(y_train)
    print("训练集中每个类别的样本数量:", train_counts)

    # 计算测试集中每个类别的样本数量
    test_counts = Counter(y_test)
    print("测试集中每个类别的样本数量:", test_counts)

    cls_num_list = [0] * num_classes
       
    for label in nosiy_labeled_dict["labels"]:
        cls_num_list[label] += 1
        
    # return sum_dataset, sum_target, num_classes
    return nosiy_labeled_dict, unlabeled_dict, val_dict, test_dict, cls_num_list

def gen_noisy_unlabeled_data(X_train, y_train, noisy_ratio=0, labeled_ratio=None, logger=None):
    
    # 去除样本标签的数量
    labeled_num = int(labeled_ratio * len(X_train))
    X_train_labeled, y_train_labeled = X_train[:labeled_num], y_train[:labeled_num]

    if noisy_ratio != 0:
        # 训练 SVM
        svm = SVC(probability=True)
        svm.fit(X_train_labeled, y_train_labeled)

       # 假设 y 是一个 numpy.ndarray
        unique_classes = np.unique(y_train_labeled)
        num_samples = y_train_labeled.shape[0]
        print(f'Number of labeled classes: {num_samples}\n, Unique classes in y: {unique_classes}')

        # 检查唯一值的数量
        if len(unique_classes) == 1:
            print("Only one class present in y. Need to check data.")

        # 在训练集上进行预测
        y_train_pred = svm.predict(X_train_labeled)
        probs = svm.predict_proba(X_train_labeled)

        # 根据每一类中预测结果与真实标签不相符的样本，按置信度选择 p% 的样本更改其标签
        y_train_noisy = np.copy(y_train_labeled)

        for class_label in np.unique(y_train_labeled):
            class_indices = np.where(y_train_labeled == class_label)[0]
            incorrect_pred_mask = y_train_pred[class_indices] != y_train_labeled[class_indices]
            incorrect_class_indices = class_indices[incorrect_pred_mask]
            class_probs = probs[incorrect_class_indices, y_train_pred[incorrect_class_indices]]

            # 获取置信度最低的样本索引
            num_to_change = int(len(incorrect_class_indices) * noisy_ratio)
            lowest_confidence_indices = np.argsort(class_probs)[:num_to_change]
                                                                                        
            # 随机更改这些样本的标签为不同于原始标签的新标签
            for idx in lowest_confidence_indices:
                original_label = y_train_labeled[incorrect_class_indices[idx]]
                possible_labels = [label for label in range(2) if label != original_label]
                new_label = np.random.choice(possible_labels)
                y_train_noisy[incorrect_class_indices[idx]] = new_label

        y_train_labeled = y_train_noisy
   
    return X_train_labeled, y_train_labeled, X_train[labeled_num+1:]

def fill_nan_value(train_set, val_set, test_set):
    ind = np.where(np.isnan(train_set))
    col_mean = np.nanmean(train_set, axis=0)
    col_mean[np.isnan(col_mean)] = 1e-6

    train_set[ind] = np.take(col_mean, ind[1])

    ind_val = np.where(np.isnan(val_set))
    val_set[ind_val] = np.take(col_mean, ind_val[1])

    ind_test = np.where(np.isnan(test_set))
    test_set[ind_test] = np.take(col_mean, ind_test[1])
    return train_set, val_set, test_set

def k_fold(data, target):
    '''
    外层划分：将数据集分成两部分：一部分用于进一步划分训练和验证集（“原始”数据集），另一部分则直接作为测试集。
    内层划分：进一步将外层划分得到的“原始”数据集分为 训练集 和 验证集
    '''
    skf = StratifiedKFold(5, shuffle=True)  # 外层划分，stratifiledKFold: 确保每一折（fold）中各个类别的样本比例大致与完整数据集中的比例相同

    # 存储每一折中训练集、验证集、测试集及其对应标签的列表
    train_sets = []
    train_targets = []

    val_sets = []
    val_targets = []

    test_sets = []
    test_targets = []

    # data 和 target 被分为“原始”（用于进一步分割成训练集和验证集）和测试集

    for raw_index, test_index in skf.split(data, target):   # 对于每一次的迭代，skf.split(data, target) 会产生两个数组 
        '''
        在每次循环中，使用 raw_index 从整个数据集中提取出“原始”数据集（即本轮将被进一步分割为训练集和验证集的部分）和对应的标签。
        然后，使用 StratifiedKFold(4, shuffle=True).split(raw_set, raw_target) 再次进行分层划分，
        这次是为了从“原始”数据集中划分出训练集和验证集。注意这里的4折划分仅用于从“原始”集合中划分一次，因此使用了 next() 来获取第一组划分的索引。
        '''
        raw_set = data[raw_index]
        raw_target = target[raw_index]

        train_index, val_index = next(StratifiedKFold(4, shuffle=True).split(raw_set, raw_target))

        train_sets.append(raw_set[train_index])
        train_targets.append(raw_target[train_index])

        val_sets.append(raw_set[val_index])
        val_targets.append(raw_target[val_index])

        test_sets.append(data[test_index])
        test_targets.append(target[test_index])

    return train_sets, train_targets, val_sets, val_targets, test_sets, test_targets

def transfer_labels(labels):
    labels = np.array(labels)
    indicies = np.unique(labels)
    num_samples = labels.shape[0]

    for i in range(num_samples):
        new_label = np.argwhere(labels[i] == indicies)[0][0]
        labels[i] = new_label
    return labels

def load_from_pt(dataset_path, dataset, noisy_ratio, labeled_ratio, logger):
    # 加载数据
    data = torch.load(f'E:\\ts_data\\{dataset}\\train.pt')
    output_dir = os.path.join(dataset_path, dataset)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    X_train = data['samples']
    y_train = data['labels']

    # pseudo
    nosiy_labeled_data = dict()
    unlabeled_dict = dict()
    # p_data['samples'] = torch.from_numpy(X_train).unsqueeze(1)

    p_X_train, p_y_train, unlabeled_X_train = gen_noisy_unlabeled_data(X_train=X_train, y_train=y_train, noisy_ratio=noisy_ratio, labeled_ratio=labeled_ratio, logger=logger)
    
    nosiy_labeled_data['samples'] = p_X_train
    nosiy_labeled_data["labels"] = p_y_train

    unlabeled_dict['samples'] = unlabeled_X_train

    # 输出每个标签及其对应的数量
    label_counts = torch.bincount(y_train)
    print(f"sample counts: {label_counts}")

    torch.save(nosiy_labeled_data, os.path.join(output_dir, "train_labeled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))    
    torch.save(unlabeled_dict, os.path.join(output_dir, "train_unlabled"+"_"+str(noisy_ratio)+"_"+str(labeled_ratio)+".pt"))
    


